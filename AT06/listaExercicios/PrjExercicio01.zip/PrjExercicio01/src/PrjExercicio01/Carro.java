package PrjExercicio01;

public class Carro {
  //atributos 
	private String marca ;
	private String modelo ;
	private String cor ; 
	private int velocidade ; 
	
	//Construtores 
	public Carro() {
		
	} 
	public Carro(String marca, String modelo, String cor, int velocidade) {
		this.marca = marca;
		this.modelo = modelo;
		this.cor = cor;
		this.velocidade = velocidade; 
	} 
	//Getters Setters 
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public int getVelocidade() {
		return velocidade;
	}
	public void setVelocidade(int velocidade) {
		this.velocidade = velocidade; 
		if (velocidade < 0) { 
			System.out.println("Velocidade não pode ser negativa");
			this.velocidade=0;
		} else {
			this.velocidade= velocidade ;
		}
	}   
	//metodos 
	void acelerar (int acelerar) {
		velocidade += acelerar; 
	}
	
	void frear (int reduzir) {
		velocidade -= reduzir;
	} 
	public void exibirinfo() {
		 System.out.println("Carro" + this.marca); 
		 System.out.println("modelo: " + this.modelo);
	 }
	
	
	
	
	
}

