package PrjExercicio01;
import java.util.Scanner;

public class carroNovo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
	   Carro carro01 = new Carro(); 
	   
	   
	   System.out.println("Qual a marca do carro?");
	   carro01.setMarca(sc.nextLine()); 
	   
	   System.out.println("Qual o modelo do carro?");
	   carro01.setModelo(sc.nextLine());
	   
	   System.out.println("Qual a cor do carro?");
	   carro01.setCor(sc.nextLine()); 
	   
	   System.out.println("Qual a velocidade do carro?");
	   carro01.setVelocidade(sc.nextInt()); 
	   
	   System.out.println("Opções:");
	   System.out.println("01-Acelerar");
	   System.out.println("02-Frear");
	   System.out.println("Escolha uma opção");
	   int escolha = sc.nextInt(); 
	   
	   if (escolha == 1) {
		   System.out.println("Quanto deseja acelerar?");
		   carro01.acelerar(sc.nextInt());
	   } 
	   else if (escolha ==2) {
		   System.out.println("Quanto deseja frear?");
		   carro01.frear(sc.nextInt());
	   } 
	   else {
		   System.out.println("Invalido!");
	   }
      sc.close();
      
	}
	

}
