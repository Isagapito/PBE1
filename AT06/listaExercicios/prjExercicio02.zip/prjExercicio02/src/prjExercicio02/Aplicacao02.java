package prjExercicio02;

public class Aplicacao02 {

	public static void main(String[] args) {
	Livro Livro01 = new Livro();
	Livro01.setTitulo("Os setes maridos de Evellyn Hugo");
	Livro01.setAutor("Taylor Jenkins");
	Livro01.setNumPaginas(350);
	Livro01.setPreco(45);
	
	Livro Livro02 = new Livro ("Mil vezes amor", "Lynn Paiter", 280, 60);
	
	Livro Livro03 = new Livro ("A biblioteca da meia noite", "Matt Haig", 340, 40);
	
	Livro01.exibirinfo();
	
	
	Livro02.exibirinfo();
	
	Livro03.exibirinfo();
	
	}

}
