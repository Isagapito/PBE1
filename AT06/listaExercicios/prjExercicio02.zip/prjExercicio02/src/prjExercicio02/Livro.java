package prjExercicio02;

public  class Livro {
   //atributos 
	private String titulo;
	private String autor; 
	private int numPaginas;
	private double preco; 
	
	//Construtores 
	public Livro () {
		
	} 
	public Livro (String titulo, String autor, int numPaginas, double preco) { 
		this.titulo = titulo; 
		this.autor = autor;
		this.numPaginas = numPaginas; 
		this.preco = preco; 
		
	} 
	//Getters Setters
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public int getNumPaginas() {
		return numPaginas;
	}
	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}   
	//metodo 
	void desconto (double desconto) {
		preco =- 15.00;
	} 
	 public void exibirinfo() {
		 System.out.println("titulo:" + this.titulo); 
		 System.out.println("preco: " + this.preco);
	 }
	
	

  }
