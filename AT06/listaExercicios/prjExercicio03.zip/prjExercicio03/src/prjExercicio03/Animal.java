package prjExercicio03;

public class Animal {
  private String nome; 
  private int idade;
  private String raca; 
  
//Construtores
		public Animal() {
			 	
		}
		public Animal(String parametroNome, String parametroRaca, int parametroIdade) {
			this.nome = parametroNome;
			this.idade = parametroIdade;
			this.raca = parametroRaca;
			
		
		}

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public int getIdade() {
			return idade;
		}

		public void setIdade(int idade) {
			this.idade = idade;
		}

		public String getRaca() {
			return raca;
		}

		public void setRaca(String raca) {
			this.raca = raca;
		} 
		//metodos 
		public void metodoEmitirSom() {
			System.out.println("Animal fez um som");
		}
		
}
