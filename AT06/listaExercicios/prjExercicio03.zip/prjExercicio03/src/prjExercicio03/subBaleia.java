package prjExercicio03;

public class subBaleia extends Animal {
	//metodos baleia 
	public void nadar() { 
		System.out.println(this.Nome + "Esta nadando");
		
	}

}
