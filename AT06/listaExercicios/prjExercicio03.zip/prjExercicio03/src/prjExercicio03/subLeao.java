package prjExercicio03;

public class subLeao extends Animal{ 
	//metodos leao
	public void metodoCacar() {
		System.out.println(this.nome + " está caçando");
	} 

}
