package prjExercicio04;

public class subCaminhao {
	//metodo 
			public void acelerar () {
				System.out.println("Caminhão esta acelerando");
			} 
			public void frear() {
				System.out.println("Caminhão esta frando");
			}
}
