package prjExercicio04;

public class subCarro extends veiculo{ 
	//metodo 
		public void acelerar () {
			System.out.println("Carro esta acelerando");
		} 
		public void frear() {
			System.out.println("Carro esta frando");
		}

}
