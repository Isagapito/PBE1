package prjExercicio04;

public class subMoto extends veiculo{ 
	//metodo 
	public void acelerar () {
		System.out.println("Moto esta acelerando");
	} 
	public void frear() {
		System.out.println("Moto esta frando");
	}

}
