package prjExercicio04;

public class veiculo {
  //atributos 
	private String marca;
	private String modelo; 
	private int velocidade; 
	
	//Construtores 
	public veiculo() {
		
	}  
	
	public veiculo (String marca, String modelo, int velocidade) {
	this.marca = marca;
	this.marca = modelo;
	this.velocidade = velocidade;
	}
	// Getters Setters
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public int getVelocidade() {
		return velocidade;
	}

	public void setVelocidade(int velocidade) {
		this.velocidade = velocidade;
	} 
	
	//metodos 
	void acelerar (int acelerar) { 
		velocidade += 10; 
		System.out.println("Veiculo acelerando");
	} 
	
	void frear (int desacelerar) {
		velocidade -= 10;
		System.out.println("Veiculo esta freando");
	}
	
}


