package br.com.bibiotecasenai.itens;

import br.com.bibliotecasenai.usuarios.Usuario;

public class Emprestimo extends Livro { 
	
	//Atributo 
	public int numeroEmprestimo;
	
	//Metodos 
	public void emprestarLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosemprestados(usuario.getLivrosemprestados()+1);
	} 
	public void devolverLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosemprestados(usuario.getLivrosemprestados()-1);
	}
	
}
