package br.com.bibiotecasenai.itens;

public class Livro {
	private String titulo;
	private String autor;
	private String inbs;
	private String disponivel;
	
	//Getters e Setters 
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getInbs() {
		return inbs;
	}
	public void setInbs(String inbs) {
		this.inbs = inbs;
	}
	public String getDisponivel() {
		return disponivel;
	}
	public void setDisponivel(String disponivel) {
		this.disponivel = disponivel;
	} 
	
	
	
}
