package br.com.bibiotecasenai.principal;

import br.com.bibliotecasenai.usuarios.Bibliotecario;
import br.com.bibliotecasenai.usuarios.Usuario;

public class Aplicacao  {

	public static void main(String[] args) {
	Usuario usuario01 = new Usuario(); 
	usuario01.setLivrosemprestados(10);
	
	Usuario usuario02 = new Usuario();
	usuario02.setLivrosemprestados(10); 
	
	Bibliotecario bibliotecario01 = new Bibliotecario(); 
	
	for(int i = 0; i >= 10; ) {
		usuario01.emprestarLivro();
	}  
	
	}

}
