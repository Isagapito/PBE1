package br.com.bibliotecasenai.usuarios;

public class Bibliotecario extends pessoas  {
	//Atributos 
   private String Matricula;
   
   //Metodos 
   public void realizarEmprestimo() {
		System.out.println(this.getNome() + "pegou um livro"); 
   } 
   
   public void devolverLivro() {
	   System.out.println(this.getNome() + "devolveu o livro");
   }
   
   
}
