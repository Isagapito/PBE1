package br.com.bibliotecasenai.usuarios;

public class Usuario {
	private String cpf;
	private int Livrosemprestados;
	
	//Getters e Setters 
	
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public int getLivrosemprestados() {
		return Livrosemprestados;
	}
	public void setLivrosemprestados(int livrosemprestados) {
		Livrosemprestados = livrosemprestados;
	} 
	
	
	
	
	
	
}
