package br.com.joalheriajoiasjoia.app.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_endereco")
public class Endereco { 
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name = "IdEndereco", nullable = false)
private Long Id_Endereco;

@Column (name = "cep", nullable = false)
private String cep ; 

@Column(name = "rua", nullable = false)
private String rua ;

@Column(name = "numCasa", nullable = false)
private String numCasa ;

@Column(name = "Cidade", nullable = false)
private String cidade ; 

@Column(name = "Estado", nullable = false)
private String estado; 

@Column(name = "Comp", nullable = false)
private String comp ;

@Column(name = "Bairro", nullable = false)
private String bairro ; 

//Construtores 
public Endereco() {
	
} 

	public Endereco (String cep, String rua, String numCasa, String cidade, String estado, String comp, String bairro) {
		this.cep = cep;
		this.rua = rua;
		this.numCasa = numCasa;
		this.cidade = cidade;
		this.estado = estado;
		this.comp = comp;
		this.bairro = bairro ;
	}

	//Getters Setters
	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public String getNumCasa() {
		return numCasa;
	}

	public void setNumCasa(String numCasa) {
		this.numCasa = numCasa;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getComp() {
		return comp;
	}

	public void setComp(String comp) {
		this.comp = comp;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	} 
	
	
}
