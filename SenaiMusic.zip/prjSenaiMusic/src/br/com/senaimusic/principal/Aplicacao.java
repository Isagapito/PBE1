package br.com.senaimusic.principal;

import br.com.senai.music.modelos.MinhasPreferidas;
import br.com.senai.music.modelos.Musica;
import br.com.senai.music.modelos.Podcast;

public class Aplicacao {

	public static void main(String[] args) {
		Musica musica01 = new Musica();
		musica01.setTitulo("First Love");
		musica01.setCantor("Mistks");
		
		for (int i = 0; i < 1000; i++) {
			musica01.reproduz();
			}
		  
		for(int i= 0; i < 50; i++) {
			musica01.curte();
		} 
		
		Podcast podcast01 = new Podcast(); 
		podcast01.setTitulo("PodPah");
		podcast01.setApresentador("Leandromeda");
		
		for (int i = 0; i< 5000; i++) {
			podcast01.reproduz();
		} 
		
		for (int i= 0; i < 4999; i++) {
			podcast01.curte();
		} 
		
		System.out.println("A musica " +musica01.getTitulo() + " tem a classificação " + musica01.getClassificacao());
		System.out.println("O Podcast " +podcast01.getTitulo() + " tem a classificação " + podcast01.getClassificacao()); 
		
		MinhasPreferidas soAsTop = new MinhasPreferidas();
		soAsTop.incluir(podcast01); 
		soAsTop.incluir(musica01);
	}  

}
